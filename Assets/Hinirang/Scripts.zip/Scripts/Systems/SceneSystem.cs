using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSystem : MonoBehaviour
{
    public enum SceneIndex
    {
        StartScreen = 0,
        Island = 1,
        TestScene = 2,
        PlayerHouse = 3,
        PlayerRoom = 4,
    }
    public static void LoadScene(int sceneIndex, float x, float y)
    {
        SceneManager.LoadScene(sceneIndex);
        GameManager.Instance.TeleportPlayer(x, y);
    }
}
