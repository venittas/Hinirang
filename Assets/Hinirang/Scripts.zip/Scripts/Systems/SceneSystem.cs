using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSystem : MonoBehaviour
{
    public SceneIndex currentPlayerLocation = SceneIndex.Island;
    public static SceneSystem Instance;
    public enum SceneIndex
    {
        StartScreen = 0,
        Island = 1,
        PlayerHouse = 2,
        PlayerRoom = 3,
        Village = 4,
        Mountain = 5,
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }
    public void LoadScene(int sceneIndex, float x, float y)
    {
        Debug.Log($"Loading scene {sceneIndex} with player position ({x}, {y})");
        GameManager.Instance.TransitionToScene(sceneIndex, x, y);
        currentPlayerLocation = (SceneIndex)sceneIndex;
    }
    public void LoadScene(int sceneIndex)
    {
        currentPlayerLocation = (SceneIndex)sceneIndex;
        SceneManager.LoadScene(sceneIndex);
    }


}
